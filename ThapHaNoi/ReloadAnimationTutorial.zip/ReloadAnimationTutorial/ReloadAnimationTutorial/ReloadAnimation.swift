//
//  ReloadAnimation.swift
//  FRCircle
//
//  Created by Hai Nguyen H.P. on 5/15/18.
//  Copyright © 2018 Asian Tech Co., Ltd. All rights reserved.
//
import UIKit

private let kRoundTime: Double = 100
private let kDefaultLineWidth: CGFloat = 2.0
private let kDefaultColor = UIColor.darkGray

class ReloadAnimation: UIView {

    private var colorArray: [UIColor] = []
    private var lineWidth: CGFloat = 0.0
    private var circleLayer = CAShapeLayer()
    private var strokeLineAnimation = CAAnimationGroup()
    private var rotationAnimation = CAAnimation()
    private var strokeColorAnimation = CAAnimation()
    private var animating = false

    override func awakeFromNib() {
        super.awakeFromNib()
        initialSetup()
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        initialSetup()
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func initialSetup() {
        layer.addSublayer(self.circleLayer)
        backgroundColor = UIColor.clear
        circleLayer.fillColor = nil
        circleLayer.lineWidth = kDefaultLineWidth
        colorArray = [kDefaultColor]
        updateAnimations()
    }

    // MARK: - Layout
    override func layoutSubviews() {
        super.layoutSubviews()
        let center = CGPoint(x: bounds.size.width / 2.0, y: bounds.size.height / 2.0)
        let diameter = min(bounds.size.width, bounds.size.height)
        let startAngle: CGFloat = 0.0
        let endAngle = 2 * CGFloat.pi
        let path = UIBezierPath(arcCenter: center, radius: (diameter - kDefaultLineWidth) / 2, startAngle: startAngle, endAngle: endAngle, clockwise: true)
        circleLayer.path = path.cgPath
        circleLayer.frame = self.bounds
    }

    // MARK: - Set attribute
    func setColors(colors: [UIColor]) {
        if !colors.isEmpty {
            colorArray = colors
        }
        updateAnimations()
    }

    func setLineWidth(lineWidth: CGFloat) {
        self.lineWidth = lineWidth
        self.circleLayer.lineWidth = self.lineWidth
    }

    // MARK: - Animations

    func startAnimation() {
        self.animating = true
        self.circleLayer.add(self.strokeLineAnimation, forKey: "strokeLineAnimation")
        self.circleLayer.add(self.rotationAnimation, forKey: "rotationAnimation")
        self.circleLayer.add(self.strokeColorAnimation, forKey: "strokeColorAnimation")
    }

    @objc func stopAnimation() {
        animating = false
        self.circleLayer.removeAnimation(forKey: "strokeLineAnimation")
        self.circleLayer.removeAnimation(forKey: "rotationAnimation")
        self.circleLayer.removeAnimation(forKey: "strokeColorAnimation")
    }

    func stopAnimationAfter(timeInterval: TimeInterval) {
        self.perform(#selector(stopAnimation), with: nil, afterDelay: timeInterval)
    }

    func isAnimating() -> Bool {
        return animating
    }

    // MARK: - Private method

    private func updateAnimations() {
        //Stroke head
        let headAnimation = CABasicAnimation(keyPath: "strokeStart")
        headAnimation.beginTime = kRoundTime / 3.0
        headAnimation.fromValue = 0
        headAnimation.toValue = 1
        headAnimation.duration = 2 * kRoundTime / 3.0
        headAnimation.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)

        //Stroke tail
        let tailAnimation = CABasicAnimation(keyPath: "strokeEnd")
        tailAnimation.fromValue = 0
        tailAnimation.toValue = 1
        tailAnimation.duration = 2 * kRoundTime / 3.0
        tailAnimation.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut)

        //Stroke line group
        let animationGroup = CAAnimationGroup()
        animationGroup.duration = kRoundTime
        animationGroup.repeatCount = .infinity
        animationGroup.animations = [headAnimation, tailAnimation]
        self.strokeLineAnimation = animationGroup

        //Rotation
        let rotationAnimation = CABasicAnimation(keyPath: "transform.rotation")
        rotationAnimation.fromValue = 0
        rotationAnimation.toValue = 2.0 * Double.pi
        rotationAnimation.duration = kRoundTime
        rotationAnimation.repeatCount = .infinity
        self.rotationAnimation = rotationAnimation

        let strokeColorAnimation = CAKeyframeAnimation(keyPath: "strokeColor")
        strokeColorAnimation.values = self.prepareColorValues()
        strokeColorAnimation.keyTimes = self.prepareKeyTimes()
        strokeColorAnimation.calculationMode = kCAAnimationDiscrete
        strokeColorAnimation.duration = Double(self.colorArray.count) * kRoundTime
        strokeColorAnimation.repeatCount = .infinity
        self.strokeColorAnimation = strokeColorAnimation
    }

    //MARK: - Animation data preparation

    func prepareColorValues() -> [CGColor] {
        var cgColors = [CGColor]()
        for color in self.colorArray {
            cgColors.append(color.cgColor)
        }
        return cgColors
    }

    func prepareKeyTimes() -> [NSNumber] {
        var keyTimes = [NSNumber]()
        for i in 0...self.colorArray.count {
            keyTimes.append(NSNumber(value: Float(i) * 1.0 / Float(self.colorArray.count)))
        }
        return keyTimes
    }

}
