//
//  ViewController.swift
//  ReloadAnimationTutorial
//
//  Created by Lam Le V. on 5/15/18.
//  Copyright © 2018 Lam Le V. All rights reserved.
//

import UIKit

private let positionxView = (UIScreen.main.bounds.size.width - 40)/2
private let positionyView = (UIScreen.main.bounds.size.height - 40)/2

class ViewController: UIViewController {

    @IBOutlet private weak var counterView: CounterView!

    override func viewDidLoad() {
        super.viewDidLoad()
        let reloadAnimation = ReloadAnimation(frame: CGRect(x: positionxView, y: positionyView, width: 40, height: 40))
        reloadAnimation.startAnimation()
        self.view.addSubview(reloadAnimation)

        counterView.startAnimation()
    }
}
