//
//  CounterView.swift
//  ReloadAnimationTutorial
//
//  Created by Lam Le V. on 5/15/18.
//  Copyright © 2018 Lam Le V. All rights reserved.
//

import UIKit

private let delta: CGFloat = .pi / 16

@IBDesignable
class CounterView: UIView {

    private struct Constants {
        static let numberOfGlasses = 8
        static let lineWidth: CGFloat = 5.0
        static let arcWidth: CGFloat = 10

        static var halfOfLineWidth: CGFloat {
            return lineWidth / 2
        }
    }

    @IBInspectable var counter: Int = 5
    @IBInspectable var outlineColor: UIColor = UIColor.blue
    @IBInspectable var counterColor: UIColor = UIColor.orange

    override func draw(_ rect: CGRect) {

        let path1 = createBezierPath(startAngle: 9 * .pi / 8, endAngle: 11 * .pi / 8)
//        let path2 = createBezierPath(startAngle: 13 * .pi / 8, endAngle: 15 * .pi / 8)
//        let path3 = createBezierPath(startAngle: 17 * .pi / 8, endAngle: 19 * .pi / 8)
//        let path4 = createBezierPath(startAngle: 5 * .pi / 8, endAngle: 7 * .pi / 8)
        counterColor.setStroke()

        path1.stroke()
//        path2.stroke()
//        path3.stroke()
//        path4.stroke()
    }

    override func awakeFromNib() {
        super.awakeFromNib()
    }

//    override func draw(_ rect: CGRect) {
//
//        let path1 = createBezierPath(startAngle: 9 * .pi / 8 - delta, endAngle: 11 * .pi / 8 + delta)
//        let path2 = createBezierPath(startAngle: 13 * .pi / 8 - delta, endAngle: 15 * .pi / 8 + delta)
//        let path3 = createBezierPath(startAngle: 17 * .pi / 8 - delta, endAngle: 19 * .pi / 8 + delta)
//        let path4 = createBezierPath(startAngle: 5 * .pi / 8 - delta, endAngle: 7 * .pi / 8 + delta)
//        counterColor.setStroke()
//
//        path1.stroke()
//        path2.stroke()
//        path3.stroke()
//        path4.stroke()
//    }

    private func createBezierPath(startAngle: CGFloat, endAngle: CGFloat) -> UIBezierPath {
        let center = CGPoint(x: bounds.width / 2, y: bounds.height / 2)
        let radius: CGFloat = max(bounds.width, bounds.height)
        let path = UIBezierPath(arcCenter: center,
                                 radius: radius/2 - Constants.arcWidth/2,
                                 startAngle: startAngle,
                                 endAngle: endAngle,
                                 clockwise: true)
        path.lineWidth = Constants.arcWidth
        return path
    }

    func startAnimation() {
        let myAnimation = CABasicAnimation(keyPath: "path")
        myAnimation.fromValue = createBezierPath(startAngle: 9 * .pi / 8, endAngle: 11 * .pi / 8).cgPath
        myAnimation.toValue = createBezierPath(startAngle: 9 * .pi / 8 - delta, endAngle: 11 * .pi / 8 + delta)
        myAnimation.duration = 0.4
        myAnimation.fillMode = kCAFillModeForwards
        myAnimation.isRemovedOnCompletion = false
        layer.mask?.add(myAnimation, forKey: "animatePath")
//        myAnimation.fromValue =
    }

//    let myAnimation = CABasicAnimation(keyPath: "path")
//
//    if (isArcVisible == true) {
//    myAnimation.fromValue = myBezierArc.CGPath
//    myAnimation.toValue = myBezierTrivial.CGPath
//    } else {
//    myAnimation.fromValue = myBezierTrivial.CGPath
//    myAnimation.toValue = myBezierArc.CGPath
//    }
//    myAnimation.duration = 0.4
//    myAnimation.fillMode = kCAFillModeForwards
//    myAnimation.removedOnCompletion = false
//
//    myImageView.layer.mask.addAnimation(myAnimation, forKey: "animatePath")

    private func createLine() {

    }
}
