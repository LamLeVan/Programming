# BezierMoon
Animate between two bezier path shapes

A couple of tricks to do this correctly.
This is a test app, the technique to be used in other apps.
